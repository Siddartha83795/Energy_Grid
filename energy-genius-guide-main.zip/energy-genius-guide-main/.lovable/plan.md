# GenAI Energy Advisor — Build Plan

A clean, professional 3-page React dashboard with a sidebar nav, green (#16a34a) accent, and Recharts visualizations. Frontend only — wires to the user's existing backend at `http://localhost:8000`.

## Pages & Routes (TanStack Start)

- `/` → **Upload** (drag-and-drop for 3 CSVs)
- `/dashboard` → **Dashboard** (cards, charts, table, recommendations)
- `/report` → **Report** (PDF preview + download)

Sidebar layout in `src/routes/__root.tsx` (or a `_app` layout route) with icons from `lucide-react`: Upload, LayoutDashboard, FileText.

## Layout & Design

- Persistent left sidebar (collapsible) with logo, nav items, active-state highlight in green.
- Top bar shows current `run_id` (from localStorage) and a "New analysis" reset button.
- Tokens added in `src/styles.css`: primary set to `#16a34a` (oklch), neutral surfaces, soft shadows, rounded-xl cards.
- Typography: Inter (body) + a slightly heavier display weight for headings — loaded via `<link>` in root head.

## Page 1 — Upload

- Three drag-and-drop zones (react-dropzone): **Energy Meter Data**, **Shift Records**, **Machine Schedules**.
- Per-file validation: `.csv` only, max size, parse header row client-side (PapaParse) and check expected columns; show green check or red error with reason.
- "Analyze" button enabled only when all 3 valid files are queued.
- On click:
  1. `POST /upload` with `multipart/form-data` (fields: `energy`, `shifts`, `schedules`) → returns `{ run_id }`.
  2. `POST /analyze` with `{ run_id }` → returns when done (loading spinner + status text).
  3. Save `run_id` to localStorage, navigate to `/dashboard`.
- Error toasts via `sonner`.

## Page 2 — Dashboard

Data: `GET /dashboard/{run_id}` via TanStack Query; loader primes the cache.

- **Summary cards (4):** Total kWh, Idle kWh, Estimated Idle Cost (₹), Machines Analyzed. Each with an icon, large number, and small delta/subtitle.
- **Bar chart (Recharts):** kWh per machine, stacked Active vs Idle. Green = active, muted amber = idle. Tooltip + legend.
- **Line chart (Recharts):** Hourly consumption trend over the selected period. Date-range selector (defaults to full range).
- **Machine table:** columns — Machine, Total kWh, Idle kWh, Utilization %, Idle Cost (₹), Status badge (Healthy / Warning / Critical based on utilization). Sortable headers, sticky header, zebra rows.
- **Recommendations panel:** numbered list rendered from the GenAI JSON contract (`summary_narrative`, `recommendations[]`, `quick_wins[]`). Each card shows rank, machine_name, issue, action, estimated savings (kWh + ₹/month), priority badge (high/med/low), effort chip.

Empty state if no `run_id` → CTA to Upload page. Error/loading states via TanStack Query.

## Page 3 — Report

- Embedded PDF preview via `<iframe src="http://localhost:8000/report/{run_id}">`.
- Prominent **Download PDF** button (anchor with `download` attribute hitting the same URL).
- Fallback message if `run_id` missing.

## API Client

- `src/lib/api.ts` with a small fetch wrapper, base URL `http://localhost:8000` (configurable via `VITE_API_BASE_URL`).
- Functions: `uploadFiles`, `analyze`, `getDashboard(run_id)`, `reportUrl(run_id)`.
- All called from the client (browser → user's local backend). No server functions needed.

## Technical Details

- **Stack:** existing TanStack Start + React 19 + Tailwind v4 + shadcn/ui.
- **New deps:** `recharts`, `react-dropzone`, `papaparse`, `@tanstack/react-query` (already in template).
- **State:** `run_id` persisted in localStorage; TanStack Query for server state.
- **No backend code in this project** — the user runs their own API at localhost:8000. No Lovable Cloud needed.
- **GenAI contract:** dashboard JSON is expected to include a `genai` field matching the specified schema (`summary_narrative`, `total_potential_savings_kwh`, `recommendations[]`, `quick_wins[]`). Recommendations panel renders directly from it.

## Files to Add/Modify

- `src/styles.css` — green primary token, surfaces.
- `src/routes/__root.tsx` — sidebar layout, fonts, head meta.
- `src/routes/index.tsx` — Upload page.
- `src/routes/dashboard.tsx` — Dashboard.
- `src/routes/report.tsx` — Report.
- `src/components/AppSidebar.tsx`, `SummaryCard.tsx`, `MachineBarChart.tsx`, `HourlyLineChart.tsx`, `MachineTable.tsx`, `RecommendationsPanel.tsx`, `Dropzone.tsx`.
- `src/lib/api.ts`, `src/lib/run-id.ts`, `src/lib/types.ts`.

## Out of Scope

- Backend implementation, auth, persistence beyond localStorage, CSV schema beyond header validation.
