import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, FileText, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getRunId, reportUrl } from "@/lib/api";

export const Route = createFileRoute("/report")({
  head: () => ({
    meta: [{ title: "Report — Energy Advisor" }],
  }),
  component: ReportPage,
});

function ReportPage() {
  const run_id = typeof window !== "undefined" ? getRunId() : null;

  if (!run_id) {
    return (
      <div className="p-8">
        <div className="rounded-2xl border bg-card p-10 text-center max-w-md mx-auto">
          <AlertTriangle className="h-10 w-10 mx-auto text-muted-foreground" />
          <h2 className="mt-3 text-lg font-semibold">No report available</h2>
          <p className="text-sm text-muted-foreground mt-1">Run an analysis first.</p>
          <Button asChild className="mt-4">
            <Link to="/">Go to upload</Link>
          </Button>
        </div>
      </div>
    );
  }

  const url = reportUrl(run_id);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-4">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <FileText className="h-7 w-7 text-primary" />
            Energy report
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">Run ID: {run_id}</p>
        </div>
        <Button asChild size="lg">
          <a href={url} download={`energy-report-${run_id}.pdf`}>
            <Download className="h-4 w-4" /> Download PDF
          </a>
        </Button>
      </header>

      <div className="rounded-2xl border bg-card shadow-sm overflow-hidden h-[80vh]">
        <iframe src={url} title="Energy report" className="w-full h-full" />
      </div>
    </div>
  );
}