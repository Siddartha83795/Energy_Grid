const BASE = (import.meta.env.VITE_API_BASE_URL as string) || "http://localhost:8000";

export type Recommendation = {
  rank: number;
  machine_name: string;
  issue: string;
  action: string;
  estimated_monthly_savings_kwh: number;
  estimated_monthly_savings_inr: number;
  priority: "high" | "medium" | "low";
  implementation_effort: "easy" | "moderate" | "complex";
};

export type MachineRow = {
  machine_name: string;
  total_kwh: number;
  idle_kwh: number;
  active_kwh: number;
  utilization_pct: number;
  idle_cost_inr: number;
};

export type HourlyPoint = { hour: string; kwh: number };

export type DashboardData = {
  summary: {
    total_kwh: number;
    idle_kwh: number;
    idle_cost_inr: number;
    machines_analyzed: number;
  };
  machines: MachineRow[];
  hourly: HourlyPoint[];
  genai: {
    summary_narrative: string;
    total_potential_savings_kwh: number;
    recommendations: Recommendation[];
    quick_wins: string[];
  };
};

export async function uploadFiles(files: { energy: File; shifts: File; schedules: File }) {
  const fd = new FormData();
  fd.append("energy", files.energy);
  fd.append("shifts", files.shifts);
  fd.append("schedules", files.schedules);
  const res = await fetch(`${BASE}/upload`, { method: "POST", body: fd });
  if (!res.ok) throw new Error(`Upload failed: ${res.status}`);
  return (await res.json()) as { run_id: string };
}

export async function analyze(run_id: string) {
  const res = await fetch(`${BASE}/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ run_id }),
  });
  if (!res.ok) throw new Error(`Analyze failed: ${res.status}`);
  return await res.json();
}

export async function getDashboard(run_id: string): Promise<DashboardData> {
  const res = await fetch(`${BASE}/dashboard/${run_id}`);
  if (!res.ok) throw new Error(`Dashboard fetch failed: ${res.status}`);
  return await res.json();
}

export function reportUrl(run_id: string) {
  return `${BASE}/report/${run_id}`;
}

export const RUN_ID_KEY = "energy_advisor_run_id";
export function getRunId() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(RUN_ID_KEY);
}
export function setRunId(id: string) {
  localStorage.setItem(RUN_ID_KEY, id);
}
export function clearRunId() {
  localStorage.removeItem(RUN_ID_KEY);
}