import { createServerFn } from "@tanstack/react-start";

type Row = {
  machine_name: string;
  total_kwh: number;
  idle_kwh: number;
  active_kwh: number;
};

export type AiInsights = {
  summary_narrative: string;
  total_potential_savings_kwh: number;
  predicted_next_month_kwh: number;
  recommendations: Array<{
    rank: number;
    machine_name: string;
    issue: string;
    action: string;
    estimated_monthly_savings_kwh: number;
    estimated_monthly_savings_inr: number;
    priority: "high" | "medium" | "low";
    implementation_effort: "easy" | "moderate" | "complex";
  }>;
  quick_wins: string[];
};

export const analyzeEnergy = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => {
    const o = input as { rows?: Row[]; tariff?: number };
    if (!o || !Array.isArray(o.rows)) throw new Error("rows required");
    return { rows: o.rows, tariff: Number(o.tariff ?? 8) };
  })
  .handler(async ({ data }) => {
    const key = process.env.GROQ_API_KEY;
    if (!key) throw new Error("GROQ_API_KEY not configured");

    const rows = data.rows.slice(0, 50);
    const totalKwh = rows.reduce((s, r) => s + Number(r.total_kwh || 0), 0);
    const idleKwh = rows.reduce((s, r) => s + Number(r.idle_kwh || 0), 0);

    const sys = `You are an industrial energy efficiency expert. Reply ONLY with strict JSON (no markdown, no code fences) matching exactly this shape:
{"summary_narrative":string,"total_potential_savings_kwh":number,"predicted_next_month_kwh":number,"recommendations":[{"rank":number,"machine_name":string,"issue":string,"action":string,"estimated_monthly_savings_kwh":number,"estimated_monthly_savings_inr":number,"priority":"high"|"medium"|"low","implementation_effort":"easy"|"moderate"|"complex"}],"quick_wins":string[]}.
Tariff for INR conversion: ${data.tariff} INR/kWh. Top 5 recommendations max. Predict next month assuming similar utilization.`;

    const user = `Machine usage data (kWh):\n${JSON.stringify(rows)}\n\nOverall totals: total=${totalKwh.toFixed(1)} kWh, idle=${idleKwh.toFixed(1)} kWh.`;

    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        temperature: 0.3,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content: user },
        ],
      }),
    });

    if (!res.ok) {
      const t = await res.text();
      throw new Error(`Groq API error ${res.status}: ${t.slice(0, 200)}`);
    }
    const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const content = json.choices?.[0]?.message?.content ?? "{}";
    try {
      return JSON.parse(content) as AiInsights;
    } catch {
      throw new Error("AI returned non-JSON response");
    }
  });