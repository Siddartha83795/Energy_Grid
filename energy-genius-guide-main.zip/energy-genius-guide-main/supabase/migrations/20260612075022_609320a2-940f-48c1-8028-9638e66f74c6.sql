
-- Roles enum
create type public.app_role as enum ('admin', 'staff');

-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  company text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

-- User roles
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

-- has_role security definer
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- Energy entries (manual or csv-imported)
create type public.entry_kind as enum ('detailed', 'daily');
create type public.entry_source as enum ('manual', 'csv');
create table public.energy_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind entry_kind not null,
  source entry_source not null default 'manual',
  machine_name text not null,
  -- detailed
  recorded_at timestamptz,
  kwh numeric,
  status text, -- active|idle
  -- daily
  entry_date date,
  total_kwh numeric,
  idle_kwh numeric,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index energy_entries_user_idx on public.energy_entries(user_id);
grant select, insert, update, delete on public.energy_entries to authenticated;
grant all on public.energy_entries to service_role;
alter table public.energy_entries enable row level security;

-- User settings
create table public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  theme text not null default 'system',
  currency text not null default 'INR',
  tariff_per_kwh numeric not null default 8.0,
  notifications_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.user_settings to authenticated;
grant all on public.user_settings to service_role;
alter table public.user_settings enable row level security;

-- updated_at trigger
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;

create trigger profiles_updated before update on public.profiles
  for each row execute function public.tg_set_updated_at();
create trigger energy_entries_updated before update on public.energy_entries
  for each row execute function public.tg_set_updated_at();
create trigger user_settings_updated before update on public.user_settings
  for each row execute function public.tg_set_updated_at();

-- Auto-create profile + role on signup (first user = admin)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_count int;
  v_role app_role;
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''));

  select count(*) into v_count from public.user_roles;
  v_role := case when v_count = 0 then 'admin'::app_role else 'staff'::app_role end;
  insert into public.user_roles (user_id, role) values (new.id, v_role);

  insert into public.user_settings (user_id) values (new.id);
  return new;
end; $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- RLS policies
-- profiles: users see/edit own; admins see/edit all
create policy "profiles self select" on public.profiles for select to authenticated
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'));
create policy "profiles self update" on public.profiles for update to authenticated
  using (auth.uid() = id or public.has_role(auth.uid(), 'admin'));
create policy "profiles admin insert" on public.profiles for insert to authenticated
  with check (auth.uid() = id or public.has_role(auth.uid(), 'admin'));
create policy "profiles admin delete" on public.profiles for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- user_roles: read all (so admin UI works), admin write
create policy "user_roles read" on public.user_roles for select to authenticated using (true);
create policy "user_roles admin write" on public.user_roles for insert to authenticated
  with check (public.has_role(auth.uid(), 'admin'));
create policy "user_roles admin update" on public.user_roles for update to authenticated
  using (public.has_role(auth.uid(), 'admin'));
create policy "user_roles admin delete" on public.user_roles for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- energy_entries: owners + admins
create policy "entries owner select" on public.energy_entries for select to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "entries owner insert" on public.energy_entries for insert to authenticated
  with check (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "entries owner update" on public.energy_entries for update to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "entries owner delete" on public.energy_entries for delete to authenticated
  using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));

-- settings: owner only
create policy "settings owner all" on public.user_settings for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
